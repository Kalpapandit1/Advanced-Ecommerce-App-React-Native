import React from 'react'

export default function useListner() {
     
    return null
}
