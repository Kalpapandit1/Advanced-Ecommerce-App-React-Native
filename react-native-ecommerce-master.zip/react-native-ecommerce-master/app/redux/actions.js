
import { SET_ERROR} from "./actionTypes";

export const setError=(data)=>({
    type:SET_ERROR,
    payload:data
  })
  /* here you can add your action */