// you can add your action type here
export const SET_ERROR="SET_ERROR"
export const SET_ERROR_SUCCESS="SET_ERROR_SUCCESS"