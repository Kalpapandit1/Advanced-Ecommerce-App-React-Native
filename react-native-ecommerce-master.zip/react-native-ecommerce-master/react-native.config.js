module.exports = {
    project: {
      ios: {},
      android: {},
    },
    assets: [],
    dependencies: {}, // make sure this dependencies are all valid installed packages or empty if you don't need it
  };